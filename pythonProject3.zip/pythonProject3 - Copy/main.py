import time
input('You were driving your car alone through the woods far from civilization when suddenly your car breaks down.')
input('With no cellular signal or help nearby, you try to find the nearest town to reach out for help.')
time.sleep(0.5)
input('You get out of the car and walk straight until you reach a fork in the road.')
time.sleep(0.5)
directions = ['1-Continue walking straight', '2-Turn right', '3-Turn left']
input(directions)
answer = input('please input 1, 2 or 3')
if answer == '1':
    print('You walk deep into the none ending woods and you get lost', 'You lost')
elif answer == '2':
    print('You  turn right and soon you find another fork in the road', '1-Turn right, 2-Turn left')